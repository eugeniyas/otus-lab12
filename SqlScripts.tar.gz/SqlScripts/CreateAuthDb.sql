CREATE DATABASE otusdb_auth;
GO

USE otusdb_auth;
GO

CREATE TABLE [dbo].[Users]
(
	[Id] INT NOT NULL IDENTITY (1,1),
    [Login] NVARCHAR(128) NOT NULL,
    [Password] NVARCHAR(128) NOT NULL,
    [Email] NVARCHAR(128),
    [Phone] NVARCHAR(128),
    [LastName] NVARCHAR(256),
    [FirstName] NVARCHAR(256),

	CONSTRAINT [PK_Users] 
		PRIMARY KEY CLUSTERED ([Id])
);
GO

INSERT INTO dbo.Users ([Login], [Password], [Email], [Phone], [LastName], [FirstName])
VALUES ('admin', 'admin', 'admin@gmail.com', '+711155577', 'Ivanov', 'Ivan');
GO
