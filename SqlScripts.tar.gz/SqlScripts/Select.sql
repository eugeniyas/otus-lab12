SELECT	*
FROM	otusdb_registry.dbo.Directions

SELECT	*
FROM	otusdb_registry.dbo.DirectionEvents

SELECT	*
FROM	otusdb_hematology.dbo.Directions

SELECT	*
FROM	otusdb_examination.dbo.Directions

SELECT	*
FROM	otusdb_operation.dbo.Directions