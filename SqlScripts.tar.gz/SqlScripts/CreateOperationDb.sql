CREATE DATABASE otusdb_operation;
GO

USE otusdb_operation;
GO

CREATE TABLE [dbo].[Directions]
(
	[Id] INT NOT NULL,
	[DonorId] INT NOT NULL,
	[CurrentState] INT NOT NULL,
	[RegDate] DATETIME NOT NULL,
	[RegUserId] INT NOT NULL,
	[LastModifiedDate] DATETIME NULL,
	[LastModifiedUserId] INT NULL,

	CONSTRAINT [PK_Directions] 
		PRIMARY KEY CLUSTERED ([Id])
);
GO
