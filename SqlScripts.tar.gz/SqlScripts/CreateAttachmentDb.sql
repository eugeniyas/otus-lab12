CREATE DATABASE otusdb_attachment_01;
GO

USE otusdb_attachment_01;
GO

CREATE TABLE [dbo].[Attachments]
(
	[Id] INT IDENTITY(1,1) NOT NULL,
	[Name] NVARCHAR(100) NOT NULL,
	[ContentType] NVARCHAR(100) NOT NULL,
	[Content] VARBINARY(MAX) NOT NULL
	
	CONSTRAINT [PK_Attachments] 
		PRIMARY KEY CLUSTERED ([Id])
);
GO



CREATE DATABASE otusdb_attachment_02;
GO

USE otusdb_attachment_02;
GO

CREATE TABLE [dbo].[Attachments]
(
	[Id] INT IDENTITY(1,1) NOT NULL,
	[Name] NVARCHAR(100) NOT NULL,
	[ContentType] NVARCHAR(100) NOT NULL,
	[Content] VARBINARY(MAX) NOT NULL
	
	CONSTRAINT [PK_Attachments] 
		PRIMARY KEY CLUSTERED ([Id])
);
GO