CREATE DATABASE otusdb_admin;
GO

USE otusdb_admin;
GO

CREATE TABLE [dbo].[DonationTypes]
(
	[Id] INT NOT NULL IDENTITY(1,1),
	[Code] NVARCHAR(4) NOT NULL,
	[Name] NVARCHAR(100) NOT NULL,
	[ShortName] NVARCHAR(50) NOT NULL,

	CONSTRAINT [PK_DonationTypes] 
		PRIMARY KEY CLUSTERED ([Id])
);
GO
